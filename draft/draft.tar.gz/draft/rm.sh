
rm *to.pdf
rm *.dvi *.aux *.bib *.log
